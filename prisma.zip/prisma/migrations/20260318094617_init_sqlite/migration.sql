-- CreateTable
CREATE TABLE "Facility" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "facilityId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "capacityTons" INTEGER NOT NULL,
    "managerName" TEXT NOT NULL,
    "contactNumber" TEXT NOT NULL,
    "latitude" REAL NOT NULL,
    "longitude" REAL NOT NULL,
    "brand" TEXT NOT NULL,
    "freeText" TEXT,
    "genetecGuid" TEXT
);

-- CreateTable
CREATE TABLE "Zone" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "facilityId" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "genetecGuid" TEXT,
    CONSTRAINT "Zone_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES "Facility" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Device" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "zoneId" INTEGER NOT NULL,
    "edgeDeviceId" INTEGER,
    "name" TEXT NOT NULL,
    "ip" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "x" REAL NOT NULL,
    "y" REAL NOT NULL,
    "polygon" TEXT,
    "rtsp_link" TEXT,
    "edge_devices_found" TEXT,
    "status" TEXT DEFAULT 'unknown',
    "supportedOnvifProfiles" TEXT,
    "deviceType" TEXT DEFAULT 'camera',
    "genetecGuid" TEXT,
    "enabledUseCases" TEXT,
    CONSTRAINT "Device_edgeDeviceId_fkey" FOREIGN KEY ("edgeDeviceId") REFERENCES "EdgeDevice" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Device_zoneId_fkey" FOREIGN KEY ("zoneId") REFERENCES "Zone" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "EdgeDevice" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "facilityId" INTEGER,
    "name" TEXT NOT NULL,
    "macAddress" TEXT NOT NULL,
    "configuration" TEXT,
    "workingScriptPath" TEXT,
    "testingScriptPath" TEXT,
    "zippedFilesPath" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "ipAddress" TEXT,
    CONSTRAINT "EdgeDevice_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES "Facility" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "EdgeDeviceHistory" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "edgeDeviceId" INTEGER NOT NULL,
    "hostname" TEXT NOT NULL,
    "macAddress" TEXT NOT NULL,
    "configuration" TEXT,
    "ipAddress" TEXT,
    "zippedFilesPath" TEXT,
    "status" TEXT NOT NULL,
    "facilityId" INTEGER,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "EdgeDeviceHistory_edgeDeviceId_fkey" FOREIGN KEY ("edgeDeviceId") REFERENCES "EdgeDevice" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Protocol" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "Device_Protocols" (
    "deviceId" INTEGER NOT NULL,
    "protocolId" INTEGER NOT NULL,

    PRIMARY KEY ("deviceId", "protocolId"),
    CONSTRAINT "Device_Protocols_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Device_Protocols_protocolId_fkey" FOREIGN KEY ("protocolId") REFERENCES "Protocol" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Snapshot" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "deviceId" INTEGER NOT NULL,
    "zoneId" INTEGER NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'snapshot',
    "filePath" TEXT NOT NULL,
    "timestamp" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Snapshot_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Snapshot_zoneId_fkey" FOREIGN KEY ("zoneId") REFERENCES "Zone" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Employee" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "phoneNumber" TEXT,
    "facilityId" INTEGER,
    "email" TEXT,
    "plate_text" TEXT,
    "cardholder" TEXT,
    "cardFormat" TEXT,
    CONSTRAINT "Employee_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES "Facility" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "VisualizerConfig" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'inactive',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "facilityId" INTEGER NOT NULL,
    "edgeDeviceId" INTEGER NOT NULL,
    CONSTRAINT "VisualizerConfig_edgeDeviceId_fkey" FOREIGN KEY ("edgeDeviceId") REFERENCES "EdgeDevice" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "VisualizerConfig_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES "Facility" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "CameraDiagnosticsHistory" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "cameraId" INTEGER NOT NULL,
    "protocol" TEXT NOT NULL,
    "success" BOOLEAN NOT NULL,
    "details" TEXT,
    "runAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isScheduled" BOOLEAN NOT NULL DEFAULT false,
    "schedulerId" TEXT,
    CONSTRAINT "CameraDiagnosticsHistory_cameraId_fkey" FOREIGN KEY ("cameraId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "CameraScheduler" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "schedulerId" TEXT NOT NULL,
    "cameraId" INTEGER NOT NULL,
    "edgeDeviceId" INTEGER NOT NULL,
    "intervalMinutes" INTEGER NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "startedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastRunAt" DATETIME,
    "nextRunAt" DATETIME,
    "totalRuns" INTEGER NOT NULL DEFAULT 0,
    "successfulRuns" INTEGER NOT NULL DEFAULT 0,
    "createdBy" TEXT,
    "cameraDetails" TEXT NOT NULL,
    CONSTRAINT "CameraScheduler_cameraId_fkey" FOREIGN KEY ("cameraId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "_DeviceToVisualizerConfig" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_DeviceToVisualizerConfig_A_fkey" FOREIGN KEY ("A") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_DeviceToVisualizerConfig_B_fkey" FOREIGN KEY ("B") REFERENCES "VisualizerConfig" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "Facility_facilityId_key" ON "Facility"("facilityId");

-- CreateIndex
CREATE UNIQUE INDEX "Facility_genetecGuid_key" ON "Facility"("genetecGuid");

-- CreateIndex
CREATE UNIQUE INDEX "Zone_genetecGuid_key" ON "Zone"("genetecGuid");

-- CreateIndex
CREATE INDEX "Zone_facilityId_idx" ON "Zone"("facilityId");

-- CreateIndex
CREATE UNIQUE INDEX "Device_genetecGuid_key" ON "Device"("genetecGuid");

-- CreateIndex
CREATE INDEX "Device_edgeDeviceId_idx" ON "Device"("edgeDeviceId");

-- CreateIndex
CREATE INDEX "Device_zoneId_idx" ON "Device"("zoneId");

-- CreateIndex
CREATE INDEX "Device_zoneId_edgeDeviceId_idx" ON "Device"("zoneId", "edgeDeviceId");

-- CreateIndex
CREATE INDEX "Device_ip_idx" ON "Device"("ip");

-- CreateIndex
CREATE INDEX "Device_status_idx" ON "Device"("status");

-- CreateIndex
CREATE UNIQUE INDEX "EdgeDevice_macAddress_key" ON "EdgeDevice"("macAddress");

-- CreateIndex
CREATE INDEX "EdgeDevice_facilityId_idx" ON "EdgeDevice"("facilityId");

-- CreateIndex
CREATE INDEX "EdgeDevice_status_idx" ON "EdgeDevice"("status");

-- CreateIndex
CREATE INDEX "EdgeDevice_ipAddress_idx" ON "EdgeDevice"("ipAddress");

-- CreateIndex
CREATE UNIQUE INDEX "Protocol_name_key" ON "Protocol"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Snapshot_deviceId_type_key" ON "Snapshot"("deviceId", "type");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_phoneNumber_key" ON "Employee"("phoneNumber");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_email_key" ON "Employee"("email");

-- CreateIndex
CREATE INDEX "Employee_phoneNumber_idx" ON "Employee"("phoneNumber");

-- CreateIndex
CREATE INDEX "Employee_email_idx" ON "Employee"("email");

-- CreateIndex
CREATE INDEX "Employee_facilityId_idx" ON "Employee"("facilityId");

-- CreateIndex
CREATE INDEX "Employee_facilityId_phoneNumber_idx" ON "Employee"("facilityId", "phoneNumber");

-- CreateIndex
CREATE INDEX "Employee_plate_text_idx" ON "Employee"("plate_text");

-- CreateIndex
CREATE INDEX "CameraDiagnosticsHistory_cameraId_runAt_idx" ON "CameraDiagnosticsHistory"("cameraId", "runAt");

-- CreateIndex
CREATE INDEX "CameraDiagnosticsHistory_schedulerId_runAt_idx" ON "CameraDiagnosticsHistory"("schedulerId", "runAt");

-- CreateIndex
CREATE INDEX "CameraDiagnosticsHistory_isScheduled_runAt_idx" ON "CameraDiagnosticsHistory"("isScheduled", "runAt");

-- CreateIndex
CREATE UNIQUE INDEX "CameraScheduler_schedulerId_key" ON "CameraScheduler"("schedulerId");

-- CreateIndex
CREATE UNIQUE INDEX "CameraScheduler_cameraId_key" ON "CameraScheduler"("cameraId");

-- CreateIndex
CREATE INDEX "CameraScheduler_isActive_nextRunAt_idx" ON "CameraScheduler"("isActive", "nextRunAt");

-- CreateIndex
CREATE INDEX "CameraScheduler_cameraId_idx" ON "CameraScheduler"("cameraId");

-- CreateIndex
CREATE INDEX "CameraScheduler_schedulerId_idx" ON "CameraScheduler"("schedulerId");

-- CreateIndex
CREATE UNIQUE INDEX "_DeviceToVisualizerConfig_AB_unique" ON "_DeviceToVisualizerConfig"("A", "B");

-- CreateIndex
CREATE INDEX "_DeviceToVisualizerConfig_B_index" ON "_DeviceToVisualizerConfig"("B");
